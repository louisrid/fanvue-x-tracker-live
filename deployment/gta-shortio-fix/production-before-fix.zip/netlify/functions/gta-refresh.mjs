/** Scheduled X metrics for GTA VI, using the same two-hour cadence as X Tracker. */
import {refreshGtaMetrics} from './gta-report.mjs';
export default async ()=>{
  try{const result=await refreshGtaMetrics({manual:false});
    console.log(JSON.stringify({job:'gta-refresh',updated:result.updated,total:result.total,errors:result.errors?.length}));
    return new Response('OK',{status:200});
  }catch(e){console.error('GTA VI refresh failed:',String(e.message||e));return new Response('Refresh failed',{status:503});}
};
export const config={schedule:'0 */2 * * *'};
