import test from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import {parseRows,publishedQrts} from '../netlify/functions/gta-report.mjs';
import {campaignLinkClicks} from '../netlify/lib/gta-shortio.mjs';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const tab='X Accounts 15 (GTA VI QRTs)';
const qrt={campaign:'GTAQ',sourceTab:tab,posted:true,paid:true,cost:50,publisher:'QRT publisher',postUrl:'https://x.com/publisher/status/2122351628162641990',trackingUrl:'https://example.s.gy/qrt',views:1000,likes:20,reposts:5,replies:5};
test('live parser needs only tab 15; source boundary excludes originals, drafts and invalid posts',()=>{
 const workbook=new ExcelJS.Workbook(),sheet=workbook.addWorksheet(tab);
 sheet.getRow(7).values=['ACCOUNT','LINK',null,'UTM LINK','ACCOUNT SUM','PAID?','POSTED?','LINK'];
 sheet.getRow(8).values=['QRT publisher','',null,qrt.trackingUrl,50,true,true,qrt.postUrl];
 const live=publishedQrts(parseRows(workbook));assert.equal(live.length,1);
 const mixed=[...live,{...qrt,campaign:'GTA1'},{...qrt,campaign:'GTA2'},{...qrt,sourceTab:'Other'},{...qrt,posted:false},{...qrt,postUrl:''}];
 assert.deepEqual(publishedQrts(mixed),live);assert.equal(mixed.length,6);
 sheet.getRow(9).values=['New QRT','',null,'https://example.s.gy/new',30,true,true,'https://x.com/new/status/2122351628162641991'];
 assert.equal(publishedQrts(parseRows(workbook)).length,2);
 sheet.getRow(8).values=[];sheet.getRow(9).values=[];assert.deepEqual(publishedQrts(parseRows(workbook)),[]);
});
test('QRT-only source drives spend, views, interactions, human clicks and CPC',async()=>{
 const rows=publishedQrts([qrt,{...qrt,campaign:'GTA1',cost:900,views:999999},{...qrt,posted:false,cost:800}]);
 const data=new Map(),store={get:async k=>data.get(k),setJSON:async(k,v)=>data.set(k,v)};
 const report=await campaignLinkClicks(rows,{store,key:'test-key',fetcher:async url=>Response.json(String(url).includes('/expand')?{idString:'qrt'}:{humanClicks:25,totalClicks:999})});
 assert.equal(report.total,25);assert.equal(report.links.length,1);
 assert.equal(rows.reduce((n,p)=>n+p.cost,0),50);assert.equal(rows.reduce((n,p)=>n+p.views,0),1000);
 assert.equal(rows.reduce((n,p)=>n+p.likes+p.reposts+p.replies,0),30);assert.equal(rows[0].cost/report.total,2);
});
test('browser ignores legacy mixed caches and restores only the isolated QRT cache',()=>{
 const app=readFileSync('public/app.js','utf8'),start=app.indexOf('function restoreGtaReport()'),end=app.indexOf('gtaState.report=restoreGtaReport()',start);
 let key;const context=vm.createContext({readReportCache:k=>{key=k;return {ready:true,publishers:[qrt],scope:'mixed'};}});
 vm.runInContext(app.slice(start,end),context);assert.equal(context.restoreGtaReport(),null);assert.equal(key,'xtracker-gta-report-qrts-v1');
 context.readReportCache=()=>({ready:true,publishers:[qrt],scope:'published-qrts-v1'});assert.equal(context.restoreGtaReport().publishers.length,1);
 assert.match(app,/setInterval\(.*state.page==='gta-vi'.*loadGtaReport/);
});
