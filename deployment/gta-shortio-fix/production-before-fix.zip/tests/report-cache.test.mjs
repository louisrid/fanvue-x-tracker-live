import test from 'node:test';
import assert from 'node:assert/strict';
import {cachedReport} from '../netlify/lib/report-cache.mjs';
const request=new Request('https://fixture.test/report');
function storage(initial){let value=initial;return {get:async()=>value,setJSON:async(_,v)=>{value=v;},value:()=>value};}
test('a stale verified response returns without waiting for upstream refresh',async()=>{
 const cache=storage({savedAt:0,data:{ok:true,placements:[{clicks:73}],checkedAt:'2026-11-01'}});
 let finish;const pending=new Promise(resolve=>finish=resolve),tasks=[];
 const response=await cachedReport('test',request,{waitUntil:p=>tasks.push(p)},async()=>{await pending;return Response.json({ok:true,trackingReady:true,placements:[{clicks:74}]});},cache);
 assert.equal((await response.json()).placements[0].clicks,73);assert.equal(tasks.length,1);
 finish();await tasks[0];assert.equal(cache.value().data.placements[0].clicks,74);
});
test('failed refresh keeps the last verified snapshot',async()=>{
 const initial={savedAt:0,data:{ok:true,placements:[{clicks:73}]}},cache=storage(initial);
 const response=await cachedReport('test',new Request(request.url+'?refresh=1'),{},async()=>Response.json({ok:false},{status:503}),cache);
 assert.equal((await response.json()).placements[0].clicks,73);assert.deepEqual(cache.value(),initial);
});
test('an unverified click outage never overwrites cached figures',async()=>{
 const initial={savedAt:0,data:{ok:true,placements:[{clicks:73}]}},cache=storage(initial);
 const response=await cachedReport('test',new Request(request.url+'?refresh=1'),{},async()=>Response.json({ok:true,trackingReady:false,placements:[{clicks:null}]}),cache);
 assert.equal((await response.json()).placements[0].clicks,73);
 assert.deepEqual(cache.value(),initial);
});
