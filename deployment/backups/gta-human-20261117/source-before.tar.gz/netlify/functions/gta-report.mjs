/**
 * GTA VI campaign report, independent from OF Terms and article tracking.
 * Uses the existing promotion spreadsheet, ExcelJS and Netlify Blobs.
 * GET reads verified source/cached metrics; POST performs a throttled manual X fetch.
 * Historical metrics never reset on provider errors. No synthetic UTM clicks.
 */
import ExcelJS from 'exceljs';
import {getStore} from '@netlify/blobs';
import {campaignLinkClicks,trackingLink} from '../lib/gta-shortio.mjs';
import {seed,seedVerifiedAt} from '../lib/gta-seed.mjs';

const SHEET_ID='1D8rI3BuuFHIemYZY92QFiHDMkj876F8oiwpDR6sMiTE';
const SOURCE_TABS=[['X Accounts 12 (GTA)','GTA1'],['X Accounts 14 (GTA VI V2)','GTA2'],['X Accounts 15 (GTA VI QRTs)','GTAQ']];
const SHEET_TTL=90_000;
const MANUAL_COOLDOWN=300_000;
const sheetStore=()=>getStore({name:'fanvue-gta-report-v1',consistency:'strong'});
const metricStore=()=>getStore({name:'fanvue-gta-metrics-v1',consistency:'strong'});
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
const val=c=>{const v=c?.value;if(v==null)return '';if(typeof v!=='object')return v;if(v instanceof Date)return v.toISOString();return v.result??v.text??v.richText?.map(x=>x.text).join('')??'';};
const txt=c=>String(val(c)).trim();
const link=c=>String(c?.hyperlink||c?.value?.hyperlink||txt(c)).trim();
const yes=c=>val(c)===true||txt(c).toUpperCase()==='TRUE';
const usd=c=>{let v=String(val(c)).replace(/[$,\s]/g,'');return v!==''&&Number.isFinite(Number(v))&&Number(v)>=0?Number(v):null;};
const safeUrl=(value,host)=>{try{const u=new URL(String(value));return u.protocol==='https:'&&(!host||host.some(x=>u.hostname===x))?u.href:'';}catch{return '';}};
const xPost=(url)=>{const m=String(url).match(/^https:\/\/(?:www\.)?(?:x\.com|twitter\.com)\/([A-Za-z0-9_]+)\/status\/(\d+)(?:[/?#]|$)/i);return m?{handle:m[1],id:m[2]}:null;};
const numeric=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v))&&Number(v)>=0?Number(v):null;

export function parseRows(workbook){
  const result=[];
  for(const [tab,campaign] of SOURCE_TABS){
    const sheet=workbook.getWorksheet(tab);
    if(!sheet)throw new Error('GTA source tab missing: '+tab);
    const col={};sheet.getRow(7).eachCell((c,i)=>{const name=txt(c).toUpperCase();if(name&&(!col[name]||name==='LINK'))col[name]=i;});
    for(const key of ['ACCOUNT','ACCOUNT SUM','PAID?','POSTED?','LINK'])if(!col[key])throw new Error('GTA column missing '+key+' in '+tab);
    for(let i=8;i<=sheet.rowCount;i++){
      const r=sheet.getRow(i),cell=key=>r.getCell(col[key]),publisher=txt(cell('ACCOUNT'));
      if(campaign==='GTAQ'?!publisher||publisher.length>100:!/^\w{1,20}$/.test(publisher))continue;
      const cost=usd(cell('ACCOUNT SUM')),paid=yes(cell('PAID?')),posted=yes(cell('POSTED?'));
      // The directory also contains many unselected research targets. Never treat them as placements.
      if(!paid&&!posted&&cost===null&&!trackingLink(link(r.getCell(col['UTM LINK']||4))))continue;
      const candidate=link(cell('LINK'));
      const postUrl=safeUrl(candidate,['x.com','twitter.com']);
      const profileUrl=safeUrl(txt(cell('LINK')),['x.com','twitter.com']);
      const accountUrl=safeUrl(link(r.getCell(col['ACCOUNT']+1)),['x.com','twitter.com']);
      result.push({code:`${campaign}-R${i}`,campaign,sourceRow:i,sourceTab:tab,
        publisher,profileUrl:accountUrl||(/^\w{1,20}$/.test(publisher)?`https://x.com/${publisher}`:''),postUrl:xPost(postUrl)?postUrl:'',
        cost,paid,posted:posted&&!!xPost(postUrl),trackingUrl:trackingLink(link(r.getCell(col['UTM LINK']||4)))?.url||'',clicks:null});
    }
  }
  if(!result.length)throw new Error('GTA source contains no paid/posted placements');
  // A live X status is one placement even if it is repeated in the workbook.
  const seen=new Set();return result.filter(p=>{const id=xPost(p.postUrl)?.id;const key=id?'post:'+id:p.campaign+':'+p.publisher.toLowerCase()+':'+p.trackingUrl;if(seen.has(key))return false;seen.add(key);return true;});
}

async function readWorkbook(){
  const url=`https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=xlsx`;
  const resp=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(19000)});
  if(!resp.ok)throw new Error('GTA spreadsheet export HTTP '+resp.status);
  const bytes=await resp.arrayBuffer();if(bytes.byteLength>13_000_000)throw new Error('GTA source workbook too large');
  const workbook=new ExcelJS.Workbook();await workbook.xlsx.load(Buffer.from(bytes));
  return parseRows(workbook);
}

async function sourceRows(force=false){
  const store=sheetStore();let cache=null;
  try{cache=await store.get('last-good-shortio-v3',{type:'json'});}catch{}
  if(!force&&cache?.rows?.length&&Date.now()-Date.parse(cache.at)<SHEET_TTL)return {...cache,cached:true};
  try{const rows=await readWorkbook(),updated={rows,at:new Date().toISOString(),source:'GOOGLE_SHEETS_LIVE'};
    await store.setJSON('last-good-shortio-v3',updated);return {...updated,cached:false};
  }catch(e){
    if(!cache?.rows?.length)try{cache=await store.get('last-good',{type:'json'});}catch{}
    if(cache?.rows?.length)return {...cache,cached:true,warning:'Live GTA spreadsheet unavailable; displaying last verified data.'};
    return {rows:seed,at:seedVerifiedAt,source:'VERIFIED_SNAPSHOT',cached:true,warning:'Live GTA spreadsheet unavailable; showing verified 16 Nov snapshot. Check Google Sheets export access.'};
  }
}

const mergeMetrics=(rows,metrics)=>rows.map(p=>{
  const post=xPost(p.postUrl),m=post&&metrics?.[post.id];
  if(!m?.at)return {...p,views:null,likes:null,reposts:null,replies:null,metricAt:null};
  return {...p,views:m.views,likes:m.likes,reposts:m.reposts,replies:m.replies,metricAt:m.at,metricError:m.error||''};
});

async function getMetrics(){try{return await metricStore().get('latest',{type:'json'})||{metrics:{},history:[],lastSuccessfulAt:null};}catch{return {metrics:{},history:[],lastSuccessfulAt:null};}}

export async function getReport({force=false,refreshClicks=false}={}){
  const [source,metric]=await Promise.all([sourceRows(force),getMetrics()]);
  const shortIo=await campaignLinkClicks(source.rows,{force:refreshClicks||force});
  const byLink=new Map(shortIo.links.map(p=>[trackingLink(p.trackingUrl)?.url,p]));
  const publishers=mergeMetrics(source.rows.filter(p=>p.posted===true&&xPost(p.postUrl)),metric.metrics).map(p=>{
    const reading=byLink.get(trackingLink(p.trackingUrl)?.url);
    const shared=source.rows.filter(r=>r.posted&&r.trackingUrl&&r.trackingUrl===p.trackingUrl).length>1;
    return {...p,clicks:shared?null:reading?.clicks??null,clickAt:reading?.clickAt,clickError:shared?'Shared link; see campaign link breakdown.':reading?.clickError||'',clickTracked:!!reading&&!shared,cpc:!shared&&p.paid&&p.cost!==null&&reading?.clicks>0?p.cost/reading.clicks:null};
  });
  return {ok:true,id:'GTA',name:'GTA VI',ready:true,checkedAt:new Date().toISOString(),
    source:source.source,sourceVerifiedAt:source.at,cached:source.cached,warning:source.warning||'',
    publishers,activity:[],clickTracking:true,shortIo,clickTrackingReason:'Short.io all-time total clicks, including bots, across all campaign tracking links. Each link counted once.',
    metricLastSuccessfulAt:metric.lastSuccessfulAt||null,intervalHours:2,
    metricErrors:metric.errors||[]};
}

function parseX(data,id){
  const tweet=data?.tweet;if(String(tweet?.id??tweet?.id_str??'')!==id)throw new Error('Provider returned a different X post');
  const views=numeric(tweet.views),likes=numeric(tweet.likes),reposts=numeric(tweet.retweets),replies=numeric(tweet.replies);
  if(views===null||likes===null)throw new Error('Views or likes unavailable');
  return {views,likes,reposts,replies,at:new Date().toISOString(),error:''};
}

export async function refreshGtaMetrics({manual=false,fetcher=fetch}={}){
  const st=metricStore(),last=await getMetrics(),now=Date.now();
  if(manual){
    const next=Number(last.lastManualAt||0)+MANUAL_COOLDOWN;
    if(now<next)return {...await getReport(),skipped:true,refreshReason:'cooldown',serverNow:now,nextRefreshAt:next,retryAfter:Math.ceil((next-now)/1000)};
    // Store the manual attempt before provider requests to prevent successive paid batches.
    await st.setJSON('latest',{...last,lastManualAt:now});
  }
  const source=await sourceRows(),posts=source.rows.filter(p=>p.posted).map(p=>({p,post:xPost(p.postUrl)})).filter(x=>x.post);
  const distinct=[...new Map(posts.map(x=>[x.post.id,x])).values()];
  const metrics={...last.metrics},errors=[];let updated=0;
  for(let i=0;i<distinct.length;i+=6){
    const batch=await Promise.all(distinct.slice(i,i+6).map(async ({post})=>{
      try{
        const resp=await fetcher(`https://api.fxtwitter.com/${encodeURIComponent(post.handle)}/status/${post.id}`,{headers:{accept:'application/json'},signal:AbortSignal.timeout(9000)});
        if(!resp.ok)throw new Error('X provider HTTP '+resp.status);
        const metric=parseX(await resp.json(),post.id),prior=metrics[post.id];
        if(['views','likes','reposts','replies'].some(k=>prior?.[k]>0&&metric[k]===0))throw new Error('X provider returned zero for a previously verified metric');
        return {id:post.id,metric};
      }catch(e){return {id:post.id,error:String(e.message||e)};}
    }));
    for(const item of batch){
      if(item.metric){metrics[item.id]=item.metric;updated++;}
      else{metrics[item.id]={...(metrics[item.id]||{}),error:item.error,lastAttemptAt:new Date().toISOString()};errors.push({postId:item.id,error:item.error});}
    }
  }
  const at=new Date().toISOString();const history=Array.isArray(last.history)?last.history.filter(x=>Date.parse(x.at)>now-30*86_400_000):[];
  // Keep one sample per post per 2-hour bucket, not one per request. No fabricated history.
  for(const {post} of distinct){const m=metrics[post.id];if(!m?.at||m.error)continue;
    const bucket=Math.floor(Date.parse(m.at)/7_200_000);if(!history.some(x=>x.id===post.id&&x.bucket===bucket))history.push({id:post.id,bucket,at:m.at,views:m.views,likes:m.likes,reposts:m.reposts,replies:m.replies});
  }
  const next={metrics,history,lastSuccessfulAt:updated?at:last.lastSuccessfulAt||null,lastAttemptAt:at,
    lastManualAt:manual?now:Number(last.lastManualAt||0),updated,total:distinct.length,errors};
  await st.setJSON('latest',next);
  return {...await getReport({refreshClicks:true}),refreshed:updated>0,updated,total:distinct.length,errors,
    skipped:false,serverNow:Date.now(),nextRefreshAt:manual?now+MANUAL_COOLDOWN:Number(last.lastManualAt||0)+MANUAL_COOLDOWN};
}

export default async function handler(request){
  if(request.method==='GET'||request.method==='HEAD'){
    try{return json(await getReport({force:new URL(request.url).searchParams.has('refresh')}));}
    catch(e){return json({ok:false,ready:false,error:String(e.message||e)},503);}
  }
  if(request.method==='POST'){
    try{return json(await refreshGtaMetrics({manual:true}));}
    catch(e){return json({ok:false,error:'GTA VI refresh unavailable: '+String(e.message||e)},503);}
  }
  return json({ok:false,error:'METHOD_NOT_ALLOWED'},405);
}
