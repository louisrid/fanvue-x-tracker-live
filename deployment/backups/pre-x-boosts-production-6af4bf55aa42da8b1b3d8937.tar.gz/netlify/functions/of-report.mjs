import {readOfPublishers,readOfEvents} from '../lib/of-report.mjs';
import {json,getCounts} from '../lib/shared.mjs';
import {cachedReport} from '../lib/report-cache.mjs';
export default (req,context)=>cachedReport('of-report-v1',req,context,async()=>{
  try{
    const [publishers,events]=await Promise.all([readOfPublishers(),readOfEvents()]);
    const counts=getCounts(events),groups=new Map();
    const dateFormat=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/London',year:'numeric',month:'2-digit',day:'2-digit'});
    for(const event of events){
      const parts=Object.fromEntries(dateFormat.formatToParts(new Date(event.timestamp)).map(p=>[p.type,p.value]));
      const date=`${parts.year}-${parts.month}-${parts.day}`,key=date+'|'+event.code;
      const row=groups.get(key)||{date,code:event.code,clicks:0};row.clicks++;groups.set(key,row);
    }
    return json({ok:true,id:'C001',name:'OF Terms X Promo',ready:true,checkedAt:new Date().toISOString(),
      publishers:publishers.map(p=>({...p,...(counts[p.code]||{clicks:0,lastClick:'',firstClick:''})})),activity:[...groups.values()]});
  }catch(error){console.warn('OF report unavailable',error?.name, /^[A-Z0-9_]+$/.test(error?.code||'')?error.code:'');return json({ok:false,ready:false,error:'OF spreadsheet or verified click storage is temporarily unavailable. Please retry.'},503);}
});
