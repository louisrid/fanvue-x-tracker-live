import {readFeed} from '../lib/shared.mjs';
import {refreshMetrics} from '../lib/metrics.mjs';
export async function runXRefresh(){
  const {feed,status:sheetStatus}=await readFeed({force:true});
  if(sheetStatus!=='SHEET_LIVE')throw new Error('Live Google Sheets data is unavailable. X stats were not refreshed.');
  const status=await refreshMetrics(feed.placements);
  console.log(JSON.stringify({job:'refresh-x-metrics',updated:status.updated,total:status.total,errors:status.errors}));
  return {ok:status.errors.length===0,updated:status.updated,total:status.total,lastSuccessfulAt:status.lastSuccessfulAt,errors:status.errors};
}
export default async()=>{
  const status=await runXRefresh();
  return new Response(JSON.stringify(status),{status:200,headers:{'content-type':'application/json'}});
};
export const config={schedule:'0 */2 * * *'};
