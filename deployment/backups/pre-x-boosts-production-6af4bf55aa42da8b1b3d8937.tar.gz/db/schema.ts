import { pgTable, uuid, text, timestamp, boolean, index } from 'drizzle-orm/pg-core';

// Deliberately independent of the article tracker and its stores.
export const ofClicks = pgTable('of_terms_clicks', {
  id: uuid('id').defaultRandom().primaryKey(),
  account: text('account').notNull(),
  clickedAt: timestamp('clicked_at', { withTimezone: true }).defaultNow().notNull(),
  isTest: boolean('is_test').default(false).notNull(),
}, table => [index('of_terms_account_date_idx').on(table.account, table.clickedAt)]);
