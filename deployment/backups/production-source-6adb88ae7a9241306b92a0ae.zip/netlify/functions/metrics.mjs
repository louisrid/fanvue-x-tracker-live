import {json,readFeed} from '../lib/shared.mjs';
import {readMetricState,refreshMetrics,workerAuth} from '../lib/metrics.mjs';
export default async req=>{
  if(req.method==='POST'){
    if(!workerAuth(req))return json({ok:false,error:'UNAUTHORISED'},401);
    try{const {feed}=await readFeed({force:true});const state=await refreshMetrics(feed.placements);return json({ok:state.errors.length===0,...state});}
    catch(e){return json({ok:false,error:String(e.message||e)},503);}
  }
  if(req.method!=='GET'&&req.method!=='HEAD')return json({ok:false,error:'METHOD_NOT_ALLOWED'},405);
  try{const state=await readMetricState();return json({ok:true,...state});}
  catch(e){return json({ok:false,error:'Metrics storage is unavailable'},503);}
};
