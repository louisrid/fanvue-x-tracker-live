import {readFeed} from '../lib/shared.mjs';
import {refreshMetrics} from '../lib/metrics.mjs';
export default async()=>{
  const {feed}=await readFeed({force:true});
  const status=await refreshMetrics(feed.placements);
  console.log(JSON.stringify({job:'refresh-x-metrics',updated:status.updated,total:status.total,errors:status.errors}));
  return new Response(JSON.stringify({ok:status.errors.length===0,updated:status.updated,total:status.total}),{status:200});
};
export const config={schedule:'0 */2 * * *'};
