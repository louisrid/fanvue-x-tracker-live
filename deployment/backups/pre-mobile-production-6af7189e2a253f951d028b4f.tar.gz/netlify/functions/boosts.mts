import {json} from '../lib/shared.mjs';
import {readBoosts} from '../lib/boosts.mjs';
export default async (req: Request)=>{
  if(req.method!=='GET')return json({ok:false,error:'METHOD_NOT_ALLOWED'},405);
  try{return json({ok:true,tweets:await readBoosts(),intervalHours:2},200);}
  catch{return json({ok:false,error:'X Boosts is temporarily unavailable. Previously loaded figures are preserved.'},503);}
};
